import React, { useState, useEffect } from "react"
import ProductoApi from "./ProductoApi"
import { getAllProductosApi } from '../Services/productosServices'
import Row from "react-bootstrap/esm/Row"
import Loading from "./Loading"


function ProductosApi() {

    const [productos,setProductos] = useState([])
    const [loading,setLoading] = useState(true)
    const [buscar,setBuscar] = useState ('ipod')

    useEffect(

           ()=> {

                getAllProductosApi(buscar)          
                .then(response => {
                    console.log(response)
                    setProductos(response.results)
                    setLoading(false)
                },) 
                .catch (error=> console.log(error)) 
        },
       [buscar]    
    ) 

    const handleChange = (event)=>{
   
        const value = event.target.value
       setBuscar(value)

    }
     
    if(loading){
        return(<div className="cargando">Cargando...</div>)
    }else{
    const titulo = "Productos"
    return(
        <Loading className="productos">
            
            <h1>{titulo}</h1>
            <input value={buscar} onChange={handleChange}></input>
            <Row>
            {productos.map(productoData=><ProductoApi data={productoData} />)}  
            </Row>
        </Loading>
        
    )
    }

}

export default ProductosApi

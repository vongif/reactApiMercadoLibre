import React from "react"

function NotFound() {
    
        return(
            <div className="" >
            <p>NotFound</p>
            </div>
        )
    }


export default NotFound;

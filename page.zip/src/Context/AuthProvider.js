import React, {useState} from "react"
import AuthContext from "./AuthContext"
import {useNavigate} from "react-router-dom"

function AuthProvider(props) {

    const [isLogin, setIslogin] = useState(localStorage.getItem("isLogin") || false)
    const [userInfo,setUserInfo] = useState(JSON.parse(localStorage.getItem("userInfo")) || {} )
    const navigate = useNavigate()
    const loginUser = (user) => {
        setIslogin(true)
        localStorage.setItem("isLogin",true)
        localStorage.setItem(userInfo,JSON.stringify(user))
        userInfo(user)
    }
    const logoutUser = () => {
        setIslogin(false)
        localStorage.removeItem("isLogin")
        localStorage.removeItem("userInfo")
        setUserInfo({})
        navigate("/")
    }
        return (
            <AuthContext.Provider
                value={{
                    isLogin,
                    loginUser,
                    logoutUser,
                    userInfo
                }}
            >    
            
            {props.children}    

            </AuthContext.Provider>
        )
    
}

export default AuthProvider
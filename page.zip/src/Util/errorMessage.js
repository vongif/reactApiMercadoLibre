export const loginMessage={
    "auth/user-not-found":"El email no existe",
    "auth/wrong-password":"La contraseña es incorrecta",    

} 